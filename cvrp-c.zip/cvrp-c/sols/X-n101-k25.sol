Route #1: 80 94 56 21
Route #2: 83 51 81
Route #3: 28 42 78 65 25
Route #4: 93 75
Route #5: 92 9 86
Route #6: 3 77 63
Route #7: 100 61 23
Route #8: 59 60 82
Route #9: 52 91 50
Route #10: 40 88 67 44
Route #11: 79 11 85 30
Route #12: 31 46 35
Route #13: 68 90 84 66
Route #14: 7 2 45 43 29 36 72 57
Route #15: 18 10 39
Route #16: 17 8
Route #17: 38 47 26 48 96 64 34
Route #18: 20 41 22 15
Route #19: 24 95 73 53 33 32
Route #20: 5 12 58
Route #21: 1 70 54
Route #22: 74 13 4
Route #23: 89 98 99 62 71
Route #24: 87 37 6 49 14
Route #25: 69 16 55 76
Route #26: 27 97 19
Cost 27591
